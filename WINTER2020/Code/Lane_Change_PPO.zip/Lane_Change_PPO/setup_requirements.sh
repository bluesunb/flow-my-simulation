cp requirement/params.py ~/flow/flow/core/
cp requirement/traci.py ~/flow/flow/core/kernel/vehicle/
cp requirement/my_lane_change_accel.py ~/flow/flow/envs/ring/
cp requirement/lane_change_ring.py ~/flow/flow/networks/
cp requirement/lane_change_rewards.py ~/flow/flow/core/
cp requirement/base.py ~/flow/flow/envs/